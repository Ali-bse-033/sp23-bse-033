// Require necessary modules
const express = require("express");
const mongoose = require("mongoose");
const multer = require("multer");
const path = require("path");
const expressLayouts = require("express-ejs-layouts");
const session = require("express-session");
const flash = require("connect-flash");

// Create Express app
const app = express();

// Static files
app.use(express.static("public"));
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

// Middleware for parsing
app.use(express.urlencoded({ extended: true }));

// View engine setup
app.set("view engine", "ejs");
app.use(expressLayouts);

// Session Configuration
app.use(
  session({
    secret: process.env.SESSION_SECRET || "secret-key",
    resave: false,
    saveUninitialized: false,
    cookie: {
      secure: process.env.NODE_ENV === "production",
      httpOnly: true,
      maxAge: 24 * 60 * 60 * 1000, // 24 hours
    },
  })
);

// Flash Middleware
app.use(flash());

// Set flash messages and session data in locals
app.use((req, res, next) => {
  res.locals.error_msg = req.flash("error_msg");
  res.locals.success_msg = req.flash("success_msg");
  res.locals.info_msg = req.flash("info_msg");
  res.locals.session = req.session;

  // Ensure cart is initialized
  if (!req.session.cart) {
    req.session.cart = [];
  }
  res.locals.cartItemCount = req.session.cart.reduce(
    (total, item) => total + item.quantity,
    0
  );
  next();
});

// Multer Storage Configuration
const storage = multer.diskStorage({
  destination: "./uploads/",
  filename: (req, file, cb) => {
    cb(null, Date.now() + "-" + file.originalname);
  },
});
const upload = multer({ storage: storage });

// MongoDB connection
const connectionString = "mongodb://localhost:27017/sp23-bse-033";
mongoose
  .connect(connectionString, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => {
    console.log(`Connected to MongoDB at ${connectionString}`);
  })
  .catch((err) => {
    console.error("Failed to connect to MongoDB", err.message);
  });

// Import Routers
const productRouter = require("./routes/admin/product.router");

// Use Routes
app.use("/", productRouter);

// Home Route
app.get("/", async (req, res) => {
  try {
    const ProductModel = require("./models/product.model");
    const products = await ProductModel.find().lean();
    res.render("home", { products });
  } catch (error) {
    console.error("Error fetching products:", error);
    res.status(500).render("error", {
      message: "Failed to fetch products",
      error: process.env.NODE_ENV === "development" ? error : {},
    });
  }
});

// Add to Cart Route
app.post("/add-to-cart", async (req, res) => {
  const productId = req.body.productId;
  try {
    const ProductModel = require("./models/product.model");
    const product = await ProductModel.findById(productId);
    if (!product) {
      req.flash("error_msg", "Product not found");
      return res.redirect("/");
    }

    const cartItem = req.session.cart.find((item) => item.productId === productId);
    if (cartItem) {
      cartItem.quantity += 1;
    } else {
      req.session.cart.push({
        productId: productId,
        title: product.title,
        price: product.price,
        quantity: 1,
      });
    }
    req.flash("success_msg", "Product added to cart");
    res.redirect("/");
  } catch (error) {
    console.error("Error adding product to cart:", error);
    req.flash("error_msg", "Error adding product to cart");
    res.redirect("/");
  }
});

// View Cart Route
app.get("/cart", (req, res) => {
  res.render("cart", { cart: req.session.cart });
});

// Add to Wishlist Route
app.post("/add-to-wishlist", async (req, res) => {
  if (!req.session.user) {
    req.flash("error_msg", "Please log in to add items to your wishlist.");
    return res.redirect("/");
  }

  const productId = req.body.productId;
  const userId = req.session.user._id;

  try {
    const Wishlist = require("./models/wishlist.model");
    let wishlist = await Wishlist.findOne({ user: userId });

    if (!wishlist) {
      wishlist = new Wishlist({ user: userId, products: [] });
    }

    if (!wishlist.products.includes(productId)) {
      wishlist.products.push(productId);
      await wishlist.save();
      req.flash("success_msg", "Product added to wishlist");
    } else {
      req.flash("info_msg", "Product is already in your wishlist");
    }

    res.redirect("/");
  } catch (error) {
    console.error("Error adding product to wishlist:", error);
    req.flash("error_msg", "Error adding product to wishlist");
    res.redirect("/");
  }
});

// View Wishlist Route
app.get("/wishlist", async (req, res) => {
  if (!req.session.user) {
    req.flash("error_msg", "Please log in to view your wishlist.");
    return res.redirect("/");
  }

  try {
    const Wishlist = require("./models/wishlist.model");
    const wishlist = await Wishlist.findOne({ user: req.session.user._id }).populate("products");
    res.render("wishlist", { wishlist: wishlist ? wishlist.products : [] });
  } catch (error) {
    console.error("Error fetching wishlist:", error);
    req.flash("error_msg", "Error fetching wishlist");
    res.redirect("/");
  }
});

// Remove from Wishlist Route
app.post("/remove-from-wishlist", async (req, res) => {
  if (!req.session.user) {
    req.flash("error_msg", "Please log in to manage your wishlist.");
    return res.redirect("/");
  }

  const productId = req.body.productId;
  const userId = req.session.user._id;

  try {
    const Wishlist = require("./models/wishlist.model");
    await Wishlist.findOneAndUpdate(
      { user: userId },
      { $pull: { products: productId } }
    );
    req.flash("success_msg", "Product removed from wishlist");
    res.redirect("/wishlist");
  } catch (error) {
    console.error("Error removing product from wishlist:", error);
    req.flash("error_msg", "Error removing product from wishlist");
    res.redirect("/wishlist");
  }
});
app.get("/checkout", (req, res) => {
  if (!req.session.user) {
    req.flash("error_msg", "Please log in to proceed to checkout.");
    return res.redirect("/login");
  }
  const unpurchasedItems = req.session.cart.filter(item => !item.purchased);
  res.render("checkout", { cart: unpurchasedItems });
});

// Process Payment Route
app.post("/process-payment", async (req, res) => {
  if (!req.session.user) {
    req.flash("error_msg", "Please log in to complete your purchase.");
    return res.redirect("/login");
  }

  try {
    // Here you would typically integrate with a payment gateway
    // For this example, we'll simulate a successful payment

    // Update only the unpurchased items in the cart
    req.session.cart = req.session.cart.map(item => {
      if (!item.purchased) {
        return { ...item, purchased: true };
      }
      return item;
    });

    // In a real application, you would save the order to the database here

    req.flash("success_msg", "Payment successful! Your order has been placed.");
    res.redirect("/order-confirmation");
  } catch (error) {
    console.error("Error processing payment:", error);
    req.flash("error_msg", "There was an error processing your payment. Please try again.");
    res.redirect("/checkout");
  }
});

// Order Confirmation Route
app.get("/order-confirmation", (req, res) => {
  if (!req.session.user) {
    return res.redirect("/login");
  }
  res.render("order-confirmation", { cart: req.session.cart });
});


// About Us Route
app.get("/about-us", (req, res) => {
  res.render("about-us");
});

// Categories Route
app.get("/categories", (req, res) => {
  res.render("categories");
});

// Contact Us Route
app.get("/contact-us", (req, res) => {
  const address = "CUI Lahore Defence Road Off Raiwind Road";
  const phone = "+92123456";
  res.render("contact-us", { address, phone });
});

// Start the server
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server started at http://localhost:${PORT}`);
});