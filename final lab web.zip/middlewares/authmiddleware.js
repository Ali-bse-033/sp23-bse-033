module.exports = {
    ensureAuthenticated: (req, res, next) => {
      if (req.session && req.session.user) {
        return next();
      }
      req.flash("error_msg", "Please log in first.");
      res.redirect("/admin/login");
    },
  };
  