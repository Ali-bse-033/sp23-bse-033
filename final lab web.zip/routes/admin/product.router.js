const express = require('express');
const bcrypt = require('bcrypt');
const multer = require('multer');
const path = require('path');
const { Types } = require('mongoose');

const Product = require('../../models/product.model');
const Admin = require('../../models/admin.model');
const Wishlist = require('../../models/wishlist.model');

const router = express.Router();

// Middleware
const ensureAuthenticated = (req, res, next) => {
  if (req.session.user) return next();
  req.flash('error_msg', 'Please log in to access this feature.');
  res.redirect('/admin/login');
};

// Multer Configuration
const storage = multer.diskStorage({
  destination: path.join(__dirname, '../../uploads/'),
  filename: (req, file, cb) => {
    const uniqueSuffix = `${Date.now()}-${Math.round(Math.random() * 1E9)}`;
    cb(null, `${file.fieldname}-${uniqueSuffix}${path.extname(file.originalname)}`);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB limit
  fileFilter: (req, file, cb) => {
    const allowedTypes = /jpeg|jpg|png|gif/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedTypes.test(file.mimetype);
    if (extname && mimetype) return cb(null, true);
    cb(new Error('Error: Images Only!'));
  }
});

// Admin Auth Routes
router.get('/admin/login', (req, res) => res.render('admin/login', { layout: 'admin/admin-layout' }));

router.post('/admin/login', async (req, res) => {
  const { username, password } = req.body;
  try {
    const admin = await Admin.findOne({ username });
    if (!admin || !(await bcrypt.compare(password, admin.password))) {
      req.flash('error_msg', 'Invalid credentials.');
      return res.redirect('/admin/login');
    }
    req.session.user = admin;
    res.redirect('/admin/dashboard');
  } catch (err) {
    console.error('Login error:', err);
    req.flash('error_msg', 'An error occurred during login.');
    res.redirect('/admin/login');
  }
});

router.get('/admin/register', (req, res) => res.render('admin/register', { layout: 'admin/admin-layout' }));

router.post('/admin/register', async (req, res) => {
  const { username, password, confirmPassword } = req.body;
  try {
    if (password !== confirmPassword) {
      req.flash('error_msg', 'Passwords do not match!');
      return res.redirect('/admin/register');
    }
    const existingAdmin = await Admin.findOne({ username });
    if (existingAdmin) {
      req.flash('error_msg', 'Username already exists!');
      return res.redirect('/admin/register');
    }
    const hashedPassword = await bcrypt.hash(password, 10);
    await new Admin({ username, password: hashedPassword }).save();
    req.flash('success_msg', 'Account created successfully. Please log in.');
    res.redirect('/admin/login');
  } catch (err) {
    console.error('Registration error:', err);
    req.flash('error_msg', 'An error occurred during registration.');
    res.redirect('/admin/register');
  }
});

router.get('/admin/logout', (req, res) => {
  req.session.destroy(() => res.redirect('/admin/login'));
});

// Admin Dashboard Route
router.get('/admin/dashboard', ensureAuthenticated, (req, res) => {
  res.render('admin/dashboard', { layout: 'admin/admin-layout', username: req.session.user.username });
});

// Products CRUD Routes
// GET: Product List with Pagination, Searching, Filtering, and Sorting
router.get("/admin/products", ensureAuthenticated, async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = 2; // Set limit to 2 products per page
    const search = req.query.search || '';
    const filter = req.query.filter || '';
    const sort = req.query.sort || 'title';
    const order = req.query.order === 'desc' ? -1 : 1;

    const query = {};
    if (search) {
      query.$or = [
        { title: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } }
      ];
    }
    if (filter === 'featured') {
      query.isFeatured = true;
    }

    const total = await Product.countDocuments(query);
    const pages = Math.ceil(total / limit);
    const skip = (page - 1) * limit;

    const products = await Product.find(query)
      .sort({ [sort]: order })
      .skip(skip)
      .limit(limit)
      .lean();

    res.render("admin/products", {
      layout: "admin/admin-layout",
      products,
      current: page,
      pages,
      limit,
      search,
      filter,
      sort,
      order: req.query.order || 'asc'
    });
  } catch (error) {
    console.error("Error fetching products:", error.message);
    req.flash('error_msg', 'Error fetching products.');
    res.redirect('/admin/dashboard');
  }
});

router.get('/admin/products/create', ensureAuthenticated, (req, res) => {
  res.render('admin/product-form', { layout: 'admin/admin-layout', product: null });
});

router.post('/admin/products/create', ensureAuthenticated, upload.single('image'), async (req, res) => {
  try {
    const { title, description, price } = req.body;
    const isFeatured = req.body.isFeatured === 'on';
    const newProduct = new Product({
      title,
      description,
      price: Number(price),
      isFeatured,
      image: req.file ? `/uploads/${req.file.filename}` : ''
    });
    await newProduct.save();
    req.flash('success_msg', 'Product created successfully.');
    res.redirect('/admin/products');
  } catch (error) {
    console.error('Error creating product:', error);
    req.flash('error_msg', 'Failed to create product.');
    res.redirect('/admin/products/create');
  }
});

router.get('/admin/products/edit/:id', ensureAuthenticated, async (req, res) => {
  try {
    const product = await Product.findById(req.params.id).lean();
    if (!product) {
      req.flash('error_msg', 'Product not found.');
      return res.redirect('/admin/products');
    }
    res.render('admin/product-form', { layout: 'admin/admin-layout', product });
  } catch (error) {
    console.error('Error loading product:', error);
    req.flash('error_msg', 'Error loading product.');
    res.redirect('/admin/products');
  }
});

router.post('/admin/products/edit/:id', ensureAuthenticated, upload.single('image'), async (req, res) => {
  try {
    const { title, description, price } = req.body;
    const isFeatured = req.body.isFeatured === 'on';
    const updatedProduct = {
      title,
      description,
      price: Number(price),
      isFeatured,
      ...(req.file && { image: `/uploads/${req.file.filename}` })
    };
    await Product.findByIdAndUpdate(req.params.id, updatedProduct);
    req.flash('success_msg', 'Product updated successfully.');
    res.redirect('/admin/products');
  } catch (error) {
    console.error('Error updating product:', error);
    req.flash('error_msg', 'Failed to update product.');
    res.redirect(`/admin/products/edit/${req.params.id}`);
  }
});

router.get('/admin/products/delete/:id', ensureAuthenticated, async (req, res) => {
  try {
    await Product.findByIdAndDelete(req.params.id);
    req.flash('success_msg', 'Product deleted successfully.');
    res.redirect('/admin/products');
  } catch (error) {
    console.error('Error deleting product:', error);
    req.flash('error_msg', 'Error deleting product.');
    res.redirect('/admin/products');
  }
});

router.post('/add-to-cart/:id', async (req, res) => {
  try {
    const productId = req.params.id;
    const product = await Product.findById(productId);

    if (!product) {
      req.flash('error_msg', 'Product not found');
      return res.redirect('/admin/products');
    }

    if (!req.session.cart) {
      req.session.cart = [];
    }

    const cartItem = req.session.cart.find(item => item.id === productId);

    if (cartItem) {
      cartItem.quantity += 1;
    } else {
      req.session.cart.push({
        id: productId,
        title: product.title,
        price: product.price,
        quantity: 1
      });
    }

    req.flash('success_msg', 'Product added to cart');
    res.redirect('/admin/products');
  } catch (error) {
    console.error('Error adding product to cart:', error);
    req.flash('error_msg', 'Error adding product to cart');
    res.redirect('/admin/products');
  }
});

// View Cart Route
router.get('/cart', (req, res) => {
  res.render('cart', {
    cart: req.session.cart || [],
    layout: 'admin/admin-layout'
  });
});
router.post('/add-to-wishlist/:id', ensureAuthenticated, async (req, res) => {
  try {
    const productId = req.params.id;
    const userId = req.session.user._id;

    let wishlist = await Wishlist.findOne({ user: userId });

    if (!wishlist) {
      wishlist = new Wishlist({ user: userId, products: [] });
    }

    if (!wishlist.products.includes(productId)) {
      wishlist.products.push(productId);
      await wishlist.save();
      req.flash('success_msg', 'Product added to wishlist');
    } else {
      req.flash('info_msg', 'Product is already in your wishlist');
    }

    res.redirect('/admin/products');
  } catch (error) {
    console.error('Error adding product to wishlist:', error);
    req.flash('error_msg', 'Error adding product to wishlist');
    res.redirect('/admin/products');
  }
});

// View Wishlist Route
router.get('/wishlist', ensureAuthenticated, async (req, res) => {
  try {
    const userId = req.session.user._id;
    const wishlist = await Wishlist.findOne({ user: userId }).populate('products');

    res.render('wishlist', {
      wishlist: wishlist ? wishlist.products : [],
      layout: 'admin/admin-layout'
    });
  } catch (error) {
    console.error('Error fetching wishlist:', error);
    req.flash('error_msg', 'Error fetching wishlist');
    res.redirect('/admin/products');
  }
});

module.exports = router;

